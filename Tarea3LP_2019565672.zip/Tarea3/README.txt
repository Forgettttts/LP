☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ 

( ͡° ͜ʖ ͡°)ﾉ Instrucciones y detalles tarea 3 (◕ᴥ◕ʋ)

                                                                               Nombre: Alan Eduardo Zapata Silva
                                                                                      ROL: 201956567-2
                                                                                        Paralelo: 200

Detalles para ejecucion:- Debe respetarse el orden y nombre de las carpetas
                        - Condiciones bajo las que fue probado el programa: En VScode 1.51.1 con el paquete de java (JDK) version 15, con la opcion de run  en el main de Juego.java,
                          (ejemplo: shorturl.at/kxNRY)

                                                                               ʕっ•ᴥ•ʔっ Espero le guste(◕ᴥ◕ʋ)

☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ 