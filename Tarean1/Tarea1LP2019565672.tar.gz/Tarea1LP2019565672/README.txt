☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ

( ͡° ͜ʖ ͡°)ﾉ Instrucciones y detalles tarea 1 (◕ᴥ◕ʋ)

Nombre: Alan E. Zapata Silva
ROL: 201956567-2
Paralelo: 200

Detalles para una correcta ejecucion:
			         -Contar con Python 3.0 o superior en el computador en el que se revise.

			         -El archivo input (palabras.txt) debe estar en la misma carpeta que el archivo .py (llamado.py).

			         -El programa fue hecho acorde a las instrucciones entregadas en la tarea con adicion de las consultas que fueron respondidas en el foro del curso en Aula.

			         -El output se realizara a traves de la terminal que se este usando.

ʕっ•ᴥ•ʔっ Informacion de la compilacion: Trabajo realizado con Python 3.8.6 64-bits en Windows 10, probado a traves de la terminal integrada de Visual Studio Code

☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ