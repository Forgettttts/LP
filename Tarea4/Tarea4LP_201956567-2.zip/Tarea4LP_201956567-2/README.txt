☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ 

                                                                       ( ͡° ͜ʖ ͡°)ﾉ Instrucciones y detalles tarea 4 (◕ᴥ◕ʋ)

                                                                                 Nombre: Alan Eduardo Zapata Silva
                                                                                         ROL: 201956567-2
                                                                                           Paralelo: 200

ʕっ•ᴥ•ʔっConsideraciones sobre las resoluciones:
			                    -En el problema 3) se considero el caso en el que el corte sea nulo, es decir, que la posicion de corte inicial, sea la misma posicion de corte
                                             final, lo cual deja la lista intacta (al igual de cuando uno corta una torta, si los dos cortes son en exactamente el mismo lugar, el trozo 
                                             resultante es nulo, por lo que el criss cross, deja las listas iguales).
       
                                            -En el problema 5) se hacen un total de 666 iteraciones de la suma, con el objetivo de tener una precision consistente con los ejemplos y con 
                                             pruebas varias.

                                            -Todo el codigo fue construido y probado en DrRacket, version 7.9, english by PLT. en Windows 10.

                                            -En el dispositivo que se ejecute, asegurarse de tener memoria suficiente para la ejecucion (probado con 8 [gb] de RAM).

                                            -En el caso de que en la pregunta 1) se ingrese un numero negativo, se entregara un mensaje de error, para que el programa solo acpete numeros
                                             mayores o iguales a 0.

☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ 