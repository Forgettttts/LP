☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ 

( ͡° ͜ʖ ͡°)ﾉ Instrucciones y detalles tarea 2 (◕ᴥ◕ʋ)

                                                                                                       Nombre: Alan Eduardo Zapata Silva
                                                                                                                    ROL: 201956567-2
                                                                                                                         Paralelo: 200

Detalles para una correcta ejecucion:
			         -Para printear un arreglo se le dio formato, añadiendole corchetes al principio y final, ademas de comas entre los digitos, 			          para poder separarlos y que sea mas facil distinguirlos.

			         -Para printear el ranking de structs, tambien se le dio un formato, para que los resultados no terminara pegados unos con 			                            otros.

			         -El formato considerado para los arreglos de enteros son: el primer digito indica la cantidad de elementos del arreglo que
			          lo suceden, ejemplo: {3,1,2,3} el '3' inicial indica que lo suceden 3 elementos mas, en este caso el 1, el 2 y el 3 que en
			          total son 3 elementos 

			         -Para poder compilar todo, los archivos heap.h, heap.c, main.c y makefile deben estar en la misma carpeta

			         -Para compilar usar 'make' o 'make Tarea2' ambos sirven

			         -Se incluyo el comando 'make clean' para limpiar los archivos generados anteriormente con el makefile

ʕっ•ᴥ•ʔっ Informacion de la compilacion: Trabajo probado en terminal de Ubuntu 18.04 LTS en Windows 10 con el archivo makefile (informacion de compilado
                                                                   interno: se uso gcc con los flags -W y -Wall para detectar posibles warnings).

☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ ｡ﾟ☆ﾟ. * ･ 